int _get_output_format(void)
{
    return 0;
}

int _imp____lc_codepage = 0;
